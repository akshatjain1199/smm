using System.Net.Http.Json;
using System.Text.Json.Nodes;
using EpostRxCore.Tests.Configuration;

namespace EpostRxCore.Tests.Api;

public sealed class OAuthTokenClient
{
    private readonly HttpClient _httpClient;
    private readonly ApiSettings _settings;

    public OAuthTokenClient(HttpClient httpClient, ApiSettings settings)
    {
        _httpClient = httpClient;
        _settings = settings;
    }

    public async Task<string> GetTokenAsync(CancellationToken cancellationToken = default)
    {
        var suppliedToken = SecretReader.Optional(_settings.BearerTokenEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(suppliedToken)) return suppliedToken;

        if (_settings.TokenUrl.Contains("SET_TENANT_ID", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                "Set EPOST_API_BEARER_TOKEN, or replace SET_TENANT_ID in tokenUrl and set the client credential variables.");
        }

        var form = new Dictionary<string, string>
        {
            ["grant_type"] = "client_credentials",
            ["client_id"] = SecretReader.Required(_settings.ClientIdEnvironmentVariable),
            ["client_secret"] = SecretReader.Required(_settings.ClientSecretEnvironmentVariable)
        };
        var scope = SecretReader.Optional(_settings.ScopeEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(scope)) form["scope"] = scope;

        using var response = await _httpClient.PostAsync(_settings.TokenUrl, new FormUrlEncodedContent(form), cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        response.EnsureSuccessStatusCode();
        return JsonNode.Parse(body)?["access_token"]?.GetValue<string>()
            ?? throw new InvalidOperationException("Token response did not contain access_token.");
    }
}
