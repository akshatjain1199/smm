using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Nodes;
using EpostRxCore.Tests.Configuration;
using EpostRxCore.Tests.Data;
using EpostRxCore.Tests.Models;

namespace EpostRxCore.Tests.Api;

public sealed class ApiRequestSender
{
    private readonly HttpClient _httpClient;
    private readonly ApiSettings _settings;

    public ApiRequestSender(HttpClient httpClient, ApiSettings settings)
    {
        _httpClient = httpClient;
        _settings = settings;
    }

    public async Task<ApiCallResult> PostAsync(
        string url,
        JsonNode payload,
        string bearerToken,
        ClientProfile client,
        CancellationToken cancellationToken = default)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, url);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
        request.Headers.TryAddWithoutValidation(_settings.UserIdHeaderName, _settings.UserId);
        request.Headers.TryAddWithoutValidation(_settings.SourceSystemHeaderName, client.SystemHeader);
        request.Headers.TryAddWithoutValidation(_settings.TraceIdHeaderName, Guid.NewGuid().ToString());
        var apiKey = SecretReader.Optional(_settings.PisApiKeyEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(apiKey))
        {
            request.Headers.TryAddWithoutValidation(_settings.PisApiKeyHeaderName, apiKey);
        }
        request.Content = new StringContent(PayloadTemplateService.Serialize(payload), Encoding.UTF8, "application/json");

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        JsonNode? json = null;
        try { json = JsonNode.Parse(body); } catch { /* Non-JSON errors are preserved in Body. */ }
        return new ApiCallResult(response.StatusCode, body, json);
    }
}
