using System.Net;
using System.Text.Json.Nodes;
using EpostRxCore.Tests.Configuration;
using EpostRxCore.Tests.Models;
using EpostRxCore.Tests.Utilities;

namespace EpostRxCore.Tests.Api;

public sealed class RxCoreApiClient
{
    private readonly ApiRequestSender _sender;
    private readonly ApiSettings _settings;

    public RxCoreApiClient(ApiRequestSender sender, ApiSettings settings)
    {
        _sender = sender;
        _settings = settings;
    }

    public async Task<ProducerResult> SendProducerAsync(
        JsonObject payload, string token, ClientProfile client, CancellationToken cancellationToken = default)
    {
        var response = await _sender.PostAsync(_settings.ProducerUrl, payload, token, client, cancellationToken);
        RequireAccepted(response, "Producer");
        var intakeId = response.Json.FindFirstString("intakeId", "intakeID", "id")
            ?? throw new InvalidOperationException("Producer response did not contain an intake ID.");
        var lifeCycleId = response.Json.FindFirstString("lifeCycleId", "lifecycleId", "lifeCycleID") ?? string.Empty;
        return new ProducerResult(intakeId, lifeCycleId, response);
    }

    public async Task<RxCoreResult> SendRxCoreAsync(
        JsonObject payload,
        string token,
        ClientProfile client,
        PatientData patient,
        string intakeId,
        CancellationToken cancellationToken = default)
    {
        var response = await _sender.PostAsync(_settings.RxCoreUrl, payload, token, client, cancellationToken);
        RequireAccepted(response, "RxCore");
        var order = response.Json.FindFirstString("orderId", "orderID", "orderNumber", "orderInvoiceNumber") ?? string.Empty;
        var rxNumbers = response.Json.FindAllStrings("rxNumber", "rxId", "rxID", "prescriptionNumber");
        return new RxCoreResult(intakeId, patient.PatientId, order, rxNumbers, response);
    }

    private static void RequireAccepted(ApiCallResult response, string service)
    {
        if (response.StatusCode != HttpStatusCode.Accepted)
        {
            throw new InvalidOperationException(
                $"{service} returned {(int)response.StatusCode} ({response.StatusCode}). Response: {response.Body}");
        }
    }
}
