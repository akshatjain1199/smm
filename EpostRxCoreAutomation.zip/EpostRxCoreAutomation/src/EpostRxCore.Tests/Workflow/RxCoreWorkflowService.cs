using EpostRxCore.Tests.Api;
using EpostRxCore.Tests.Configuration;
using EpostRxCore.Tests.Data;
using EpostRxCore.Tests.Drivers;
using EpostRxCore.Tests.Models;
using EpostRxCore.Tests.Pages;
using EpostRxCore.Tests.Reporting;
using EpostRxCore.Tests.Utilities;
using NUnit.Framework;
using OpenQA.Selenium;

namespace EpostRxCore.Tests.Workflow;

public sealed class RxCoreWorkflowService
{
    private readonly AutomationSettings _settings;
    private readonly PayloadTemplateService _payloads;
    private readonly OAuthTokenClient _tokens;
    private readonly RxCoreApiClient _api;

    public RxCoreWorkflowService(
        AutomationSettings settings,
        PayloadTemplateService payloads,
        OAuthTokenClient tokens,
        RxCoreApiClient api)
    {
        _settings = settings;
        _payloads = payloads;
        _tokens = tokens;
        _api = api;
    }

    public async Task<WorkflowResult> ExecuteAsync(
        ClientProfile client,
        PatientData patient,
        int medicationCount,
        HtmlExecutionReport report,
        bool validateInEpost,
        CancellationToken cancellationToken = default)
    {
        var token = await report.StepAsync("Authentication", "Obtain the bearer token without storing it in the report.",
            () => _tokens.GetTokenAsync(cancellationToken));
        var producerPayload = _payloads.BuildProducer(client, patient, medicationCount);
        var producer = await report.StepAsync("Producer API", "Submit the Producer request and validate HTTP 202 Accepted.",
            () => _api.SendProducerAsync(producerPayload, token, client, cancellationToken));
        report.AddInformation("Producer identifiers", $"Intake ID: {producer.IntakeId}; Lifecycle ID generated: {!string.IsNullOrWhiteSpace(producer.LifeCycleId)}");

        await Task.Delay(TimeSpan.FromSeconds(_settings.Api.DelayBetweenProducerAndRxCoreSeconds), cancellationToken);
        var rxPayload = _payloads.BuildRxCore(client, patient, medicationCount, producer.IntakeId, producer.LifeCycleId);
        var rxCore = await report.StepAsync("RxCore API", "Submit the RxCore request using the Producer intake ID and validate HTTP 202 Accepted.",
            () => _api.SendRxCoreAsync(rxPayload, token, client, patient, producer.IntakeId, cancellationToken));
        report.AddInformation("RxCore identifiers", $"Order number: {rxCore.OrderNumber}; Rx count in response: {rxCore.RxNumbers.Count}");

        EpostOrderSnapshot? order = null;
        if (validateInEpost)
        {
            if (string.IsNullOrWhiteSpace(rxCore.OrderNumber))
            {
                throw new InvalidOperationException("RxCore returned 202 but no order number could be extracted from the response.");
            }
            order = ValidateInEpost(client, patient, medicationCount, rxCore.OrderNumber, report, cancellationToken);
        }
        return new WorkflowResult(client, patient, producer, rxCore, order);
    }

    private EpostOrderSnapshot ValidateInEpost(
        ClientProfile client,
        PatientData patient,
        int medicationCount,
        string orderNumber,
        HtmlExecutionReport report,
        CancellationToken cancellationToken)
    {
        using var driver = BrowserFactory.Create(_settings.Epost);
        var login = new EpostLoginPage(driver, _settings.Epost);
        report.Step("Open ePost", $"Open {_settings.Epost.Environment} in Edge IE mode.",
            () => login.Open(_settings.Epost.ResolveUrl()),
            () => ScreenshotService.Capture(driver, report.ScreenshotDirectory, "open-epost"));
        report.Step("Login", "Log in using protected environment variables.",
            () => login.Login(
                SecretReader.Required(_settings.Epost.UsernameEnvironmentVariable),
                SecretReader.Required(_settings.Epost.PasswordEnvironmentVariable),
                SecretReader.Required(_settings.Epost.SitePinEnvironmentVariable)),
            () => ScreenshotService.Capture(driver, report.ScreenshotDirectory, "login"));

        var search = new EpostOrderSearchPage(driver, _settings.Epost);
        var opened = RetryUtility.UntilNotNullAsync<object>(
            () => Task.FromResult(search.TryOpenOrder(orderNumber) ? new object() : null),
            TimeSpan.FromSeconds(_settings.Epost.OrderPollTimeoutSeconds),
            TimeSpan.FromSeconds(_settings.Epost.OrderPollIntervalSeconds),
            $"Order {orderNumber} did not appear in ePost within the configured timeout.",
            cancellationToken).GetAwaiter().GetResult();

        var details = new EpostOrderDetailsPage(driver);
        var order = details.Read(orderNumber);
        var pageText = details.ReadAllVisibleText();
        report.Step("Validate order", "Validate the order number, client origination and dispense location.", () =>
        {
            Assert.Multiple(() =>
            {
                Assert.That(order.OrderNumber, Is.EqualTo(orderNumber));
                Assert.That(pageText, Does.Contain(client.ExpectedDispenseLocation).IgnoreCase);
                Assert.That(pageText, Does.Contain(client.ExpectedOrderOrigination).IgnoreCase);
                Assert.That(pageText, Does.Contain(patient.FirstName).IgnoreCase.Or.Contain(patient.LastName).IgnoreCase);
            });
        }, () => ScreenshotService.Capture(driver, report.ScreenshotDirectory, "order-validation"));
        report.Step("Validate Rx records", $"Validate {medicationCount} Rx record(s) and expected Rx origination {client.ExpectedRxOrigination}.", () =>
        {
            Assert.That(pageText, Does.Contain(client.ExpectedRxOrigination).IgnoreCase);
            Assert.That(order.Prescriptions.Count, Is.GreaterThanOrEqualTo(medicationCount));
        }, () => ScreenshotService.Capture(driver, report.ScreenshotDirectory, "rx-validation"));
        return order;
    }
}
