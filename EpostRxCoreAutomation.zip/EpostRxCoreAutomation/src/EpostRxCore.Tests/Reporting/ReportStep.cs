namespace EpostRxCore.Tests.Reporting;

public sealed record ReportStep(
    int Number,
    string Name,
    string Description,
    string Status,
    TimeSpan Duration,
    string? ScreenshotFileName);
