using OpenQA.Selenium;

namespace EpostRxCore.Tests.Reporting;

public static class ScreenshotService
{
    public static string Capture(IWebDriver driver, string directory, string stepName)
    {
        Directory.CreateDirectory(directory);
        var safeName = string.Concat(stepName.Select(character => Path.GetInvalidFileNameChars().Contains(character) ? '_' : character));
        var fileName = $"{DateTime.Now:HHmmssfff}_{safeName}.png";
        var path = Path.Combine(directory, fileName);
        ((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(path);
        return fileName;
    }
}
