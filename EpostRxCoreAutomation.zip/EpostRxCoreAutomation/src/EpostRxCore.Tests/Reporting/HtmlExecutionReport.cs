using System.Diagnostics;
using System.Net;
using System.Text;

namespace EpostRxCore.Tests.Reporting;

public sealed class HtmlExecutionReport : IDisposable
{
    private readonly List<ReportStep> _steps = [];
    private readonly string _testName;
    private readonly string _environment;
    private readonly string _reportDirectory;
    private readonly string _screenshotDirectory;
    private readonly DateTime _started = DateTime.Now;
    private bool _written;

    public HtmlExecutionReport(string rootDirectory, string testName, string environment)
    {
        _testName = testName;
        _environment = environment;
        var runFolder = $"{DateTime.Now:yyyyMMdd_HHmmssfff}_{Safe(testName)}";
        _reportDirectory = Path.GetFullPath(Path.Combine(rootDirectory, runFolder));
        _screenshotDirectory = Path.Combine(_reportDirectory, "Screenshots");
        Directory.CreateDirectory(_screenshotDirectory);
    }

    public string ScreenshotDirectory => _screenshotDirectory;
    public string ReportPath => Path.Combine(_reportDirectory, "ExecutionReport.html");

    public void Step(string name, string description, Action action, Func<string?>? screenshot = null)
    {
        var timer = Stopwatch.StartNew();
        try
        {
            action();
            timer.Stop();
            _steps.Add(new ReportStep(_steps.Count + 1, name, description, "PASS", timer.Elapsed, screenshot?.Invoke()));
        }
        catch (Exception error)
        {
            timer.Stop();
            string? image = null;
            try { image = screenshot?.Invoke(); } catch { }
            _steps.Add(new ReportStep(_steps.Count + 1, name, $"{description} Error: {error.Message}", "FAIL", timer.Elapsed, image));
            throw;
        }
    }

    public async Task<T> StepAsync<T>(string name, string description, Func<Task<T>> action)
    {
        var timer = Stopwatch.StartNew();
        try
        {
            var result = await action();
            timer.Stop();
            _steps.Add(new ReportStep(_steps.Count + 1, name, description, "PASS", timer.Elapsed, null));
            return result;
        }
        catch (Exception error)
        {
            timer.Stop();
            _steps.Add(new ReportStep(_steps.Count + 1, name, $"{description} Error: {error.Message}", "FAIL", timer.Elapsed, null));
            throw;
        }
    }

    public void AddInformation(string name, string description) =>
        _steps.Add(new ReportStep(_steps.Count + 1, name, description, "INFO", TimeSpan.Zero, null));

    public void Write()
    {
        if (_written) return;
        _written = true;
        Directory.CreateDirectory(_reportDirectory);
        var overall = _steps.Any(step => step.Status == "FAIL") ? "FAIL" : "PASS";
        var rows = string.Join(Environment.NewLine, _steps.Select(step => $"""
          <tr class="{step.Status.ToLowerInvariant()}">
            <td>{step.Number}</td><td>{H(step.Name)}</td><td>{H(step.Description)}</td>
            <td>{step.Status}</td><td>{step.Duration.TotalSeconds:0.00}s</td>
            <td>{(step.ScreenshotFileName is null ? "" : $"<a href=\"Screenshots/{Uri.EscapeDataString(step.ScreenshotFileName)}\">Open screenshot</a>")}</td>
          </tr>
        """));
        var html = $$"""
        <!doctype html><html><head><meta charset="utf-8"><title>{{H(_testName)}}</title>
        <style>
        body{font-family:Arial,sans-serif;margin:24px;color:#1f2933}h1{background:#285b2a;color:white;padding:14px;margin:0}
        .meta{background:#fff2b2;padding:12px;display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}
        table{width:100%;border-collapse:collapse}th{background:#356aa0;color:white;text-align:left;padding:9px}
        td{border:1px solid #cbd5df;padding:8px;vertical-align:top}.pass td:nth-child(4){color:#137333;font-weight:bold}
        .fail td:nth-child(4){color:#b3261e;font-weight:bold}.info td:nth-child(4){color:#2457a6;font-weight:bold}
        a{color:#174ea6}.result{font-weight:bold;color:{{(overall == "PASS" ? "#137333" : "#b3261e")}}
        </style></head><body><h1>ePostRx RxCore Functional Automation</h1>
        <div class="meta"><div><b>Test:</b> {{H(_testName)}}</div><div><b>Environment:</b> {{H(_environment)}}</div>
        <div><b>Started:</b> {{_started:yyyy-MM-dd HH:mm:ss}}</div><div><b>Result:</b> <span class="result">{{overall}}</span></div></div>
        <table><thead><tr><th>Step_No</th><th>Step_Name</th><th>Description</th><th>Status</th><th>Step_Time</th><th>Evidence</th></tr></thead>
        <tbody>{{rows}}</tbody></table></body></html>
        """;
        File.WriteAllText(ReportPath, html, Encoding.UTF8);
    }

    public void Dispose() => Write();
    private static string H(string value) => WebUtility.HtmlEncode(value);
    private static string Safe(string value) => string.Concat(value.Select(character => Path.GetInvalidFileNameChars().Contains(character) ? '_' : character));
}
