namespace EpostRxCore.Tests.Models;

public sealed record WorkflowResult(
    ClientProfile Client,
    PatientData Patient,
    ProducerResult Producer,
    RxCoreResult RxCore,
    EpostOrderSnapshot? EpostOrder);
