using System.Net;
using System.Text.Json.Nodes;

namespace EpostRxCore.Tests.Models;

public sealed record ApiCallResult(HttpStatusCode StatusCode, string Body, JsonNode? Json)
{
    public bool IsSuccess => (int)StatusCode is >= 200 and <= 299;
}

public sealed record ProducerResult(string IntakeId, string LifeCycleId, ApiCallResult Response);

public sealed record RxCoreResult(
    string IntakeId,
    string PatientId,
    string OrderNumber,
    IReadOnlyList<string> RxNumbers,
    ApiCallResult Response);
