namespace EpostRxCore.Tests.Models;

public sealed record EpostRxSnapshot(string RxNumber, string Origination, string Medication);

public sealed record EpostOrderSnapshot(
    string OrderNumber,
    string OrderStatus,
    string DispenseLocation,
    string OrderOrigination,
    string PatientName,
    IReadOnlyList<EpostRxSnapshot> Prescriptions);
