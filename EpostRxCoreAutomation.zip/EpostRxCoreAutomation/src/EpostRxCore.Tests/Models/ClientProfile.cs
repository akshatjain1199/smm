namespace EpostRxCore.Tests.Models;

public sealed class ClientProfile
{
    public string Key { get; set; } = string.Empty;
    public string SystemHeader { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string ClientProgramId { get; set; } = string.Empty;
    public string ClientName { get; set; } = string.Empty;
    public string SourceApplication { get; set; } = string.Empty;
    public string SourceProgram { get; set; } = string.Empty;
    public string TransmissionMethod { get; set; } = string.Empty;
    public string ExpectedDispenseLocation { get; set; } = string.Empty;
    public string ExpectedOrderOrigination { get; set; } = string.Empty;
    public string ExpectedRxOrigination { get; set; } = string.Empty;
}
