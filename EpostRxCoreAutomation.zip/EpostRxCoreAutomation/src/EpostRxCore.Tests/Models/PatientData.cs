namespace EpostRxCore.Tests.Models;

public sealed record PatientData(
    string PatientId,
    string FirstName,
    string LastName,
    string DateOfBirth,
    string Gender);
