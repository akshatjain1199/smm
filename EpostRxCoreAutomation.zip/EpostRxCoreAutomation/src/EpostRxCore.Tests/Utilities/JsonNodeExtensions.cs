using System.Text.Json.Nodes;

namespace EpostRxCore.Tests.Utilities;

public static class JsonNodeExtensions
{
    public static JsonNode Required(this JsonNode node, params object[] path)
    {
        JsonNode? current = node;
        foreach (var part in path)
        {
            current = part switch
            {
                string property when current is JsonObject obj => obj[property],
                int index when current is JsonArray array && index >= 0 && index < array.Count => array[index],
                _ => null
            };

            if (current is null)
            {
                throw new InvalidOperationException($"JSON path '{string.Join('.', path)}' was not found.");
            }
        }

        return current;
    }

    public static void SetValue(this JsonNode node, JsonNode? value, params object[] path)
    {
        if (path.Length == 0) throw new ArgumentException("A JSON path is required.", nameof(path));
        var parent = node.Required(path[..^1]);
        switch (path[^1])
        {
            case string property when parent is JsonObject obj:
                obj[property] = value;
                break;
            case int index when parent is JsonArray array:
                array[index] = value;
                break;
            default:
                throw new InvalidOperationException($"JSON path '{string.Join('.', path)}' cannot be assigned.");
        }
    }

    public static string? FindFirstString(this JsonNode? node, params string[] candidateNames)
    {
        if (node is JsonObject obj)
        {
            foreach (var property in obj)
            {
                if (candidateNames.Contains(property.Key, StringComparer.OrdinalIgnoreCase) &&
                    property.Value is JsonValue value && value.TryGetValue<string>(out var text) &&
                    !string.IsNullOrWhiteSpace(text))
                {
                    return text;
                }
            }

            foreach (var child in obj.Select(property => property.Value))
            {
                var result = child.FindFirstString(candidateNames);
                if (result is not null) return result;
            }
        }
        else if (node is JsonArray array)
        {
            foreach (var child in array)
            {
                var result = child.FindFirstString(candidateNames);
                if (result is not null) return result;
            }
        }

        return null;
    }

    public static IReadOnlyList<string> FindAllStrings(this JsonNode? node, params string[] candidateNames)
    {
        var values = new List<string>();
        Collect(node, candidateNames, values);
        return values.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static void Collect(JsonNode? node, string[] names, ICollection<string> values)
    {
        if (node is JsonObject obj)
        {
            foreach (var property in obj)
            {
                if (names.Contains(property.Key, StringComparer.OrdinalIgnoreCase) &&
                    property.Value is JsonValue value && value.TryGetValue<string>(out var text) &&
                    !string.IsNullOrWhiteSpace(text))
                {
                    values.Add(text);
                }
                Collect(property.Value, names, values);
            }
        }
        else if (node is JsonArray array)
        {
            foreach (var child in array) Collect(child, names, values);
        }
    }
}
