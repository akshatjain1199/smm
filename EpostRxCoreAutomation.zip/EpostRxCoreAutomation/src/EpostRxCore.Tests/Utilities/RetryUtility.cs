namespace EpostRxCore.Tests.Utilities;

public static class RetryUtility
{
    public static async Task<T> UntilNotNullAsync<T>(
        Func<Task<T?>> action,
        TimeSpan timeout,
        TimeSpan interval,
        string failureMessage,
        CancellationToken cancellationToken = default) where T : class
    {
        var deadline = DateTime.UtcNow + timeout;
        Exception? lastError = null;
        while (DateTime.UtcNow < deadline)
        {
            cancellationToken.ThrowIfCancellationRequested();
            try
            {
                var value = await action();
                if (value is not null) return value;
            }
            catch (Exception error)
            {
                lastError = error;
            }
            await Task.Delay(interval, cancellationToken);
        }

        throw new TimeoutException(failureMessage, lastError);
    }
}
