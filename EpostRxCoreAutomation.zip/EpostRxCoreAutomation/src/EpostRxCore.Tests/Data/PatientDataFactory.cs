using System.Security.Cryptography;
using EpostRxCore.Tests.Models;

namespace EpostRxCore.Tests.Data;

public static class PatientDataFactory
{
    private const string Letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    public static PatientData CreateNew()
    {
        var firstName = $"Auto{LettersOnly(6)}";
        var lastName = $"Test{LettersOnly(6)}";
        var patientId = RandomNumberGenerator.GetInt32(10_000_000, 100_000_000).ToString();
        var year = RandomNumberGenerator.GetInt32(1950, 2001);
        var month = RandomNumberGenerator.GetInt32(1, 13);
        var day = RandomNumberGenerator.GetInt32(1, DateTime.DaysInMonth(year, month) + 1);
        var gender = RandomNumberGenerator.GetInt32(0, 2) == 0 ? "F" : "M";

        return new PatientData(patientId, firstName, lastName, new DateTime(year, month, day).ToString("yyyy-MM-dd"), gender);
    }

    private static string LettersOnly(int length) => new(
        Enumerable.Range(0, length)
            .Select(_ => Letters[RandomNumberGenerator.GetInt32(Letters.Length)])
            .ToArray());
}
