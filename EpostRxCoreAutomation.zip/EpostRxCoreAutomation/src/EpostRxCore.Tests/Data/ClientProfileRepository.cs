using System.Text.Json;
using EpostRxCore.Tests.Models;

namespace EpostRxCore.Tests.Data;

public sealed class ClientProfileRepository
{
    private readonly IReadOnlyDictionary<string, ClientProfile> _profiles;

    public ClientProfileRepository(string? filePath = null)
    {
        var path = filePath ?? Path.Combine(AppContext.BaseDirectory, "TestData", "clients.json");
        var profiles = JsonSerializer.Deserialize<List<ClientProfile>>(
            File.ReadAllText(path),
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
            ?? throw new InvalidOperationException("Client profiles could not be loaded.");

        _profiles = profiles.ToDictionary(profile => profile.Key, StringComparer.OrdinalIgnoreCase);
    }

    public IReadOnlyCollection<ClientProfile> All => _profiles.Values.ToList();

    public ClientProfile Get(string key) => _profiles.TryGetValue(key, out var profile)
        ? profile
        : throw new KeyNotFoundException($"Client '{key}' is not configured.");
}
