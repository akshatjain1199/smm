using System.Text.Json;
using System.Text.Json.Nodes;
using EpostRxCore.Tests.Configuration;
using EpostRxCore.Tests.Models;
using EpostRxCore.Tests.Utilities;

namespace EpostRxCore.Tests.Data;

public sealed class PayloadTemplateService
{
    private readonly ApiSettings _settings;
    private readonly string _templateDirectory;

    public PayloadTemplateService(ApiSettings settings, string? templateDirectory = null)
    {
        _settings = settings;
        _templateDirectory = templateDirectory ?? Path.Combine(AppContext.BaseDirectory, "TestData", "Templates");
    }

    public JsonObject BuildProducer(ClientProfile client, PatientData patient, int medicationCount)
    {
        var payload = Load("producer-template.json");
        ApplyCommonValues(payload, client, patient, medicationCount);
        return payload;
    }

    public JsonObject BuildRxCore(
        ClientProfile client,
        PatientData patient,
        int medicationCount,
        string intakeId,
        string lifeCycleId)
    {
        var payload = Load("rxcore-template.json");
        ApplyCommonValues(payload, client, patient, medicationCount);
        payload["id"] = intakeId;

        // Per the confirmed flow, intake ID is the only Producer value mapped by default.
        if (_settings.MapLifecycleIdToRxCore)
        {
            payload["lifeCycleId"] = lifeCycleId;
            payload["partnerReferenceId"] = lifeCycleId;
        }

        return payload;
    }

    private JsonObject Load(string fileName) => JsonNode.Parse(File.ReadAllText(Path.Combine(_templateDirectory, fileName)))
        as JsonObject ?? throw new InvalidOperationException($"Payload template '{fileName}' is not a JSON object.");

    private static void ApplyCommonValues(JsonObject payload, ClientProfile client, PatientData patient, int medicationCount)
    {
        if (medicationCount < 1) throw new ArgumentOutOfRangeException(nameof(medicationCount));

        var now = DateTime.UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'");
        payload["source"] = client.SystemHeader;
        payload["timestamp"] = now;
        payload.SetValue(client.ClientId, "data", "clientInfo", "clientId");
        payload.SetValue(client.ClientProgramId, "data", "clientInfo", "clientProgramId");
        payload.SetValue(client.ClientName, "data", "clientInfo", "clientName");
        payload.SetValue(client.SourceApplication, "data", "sourceApplication");
        payload.SetValue(client.SourceProgram, "data", "sourceProgram");
        payload.SetValue(client.TransmissionMethod, "data", "transmissionMethod");
        payload.SetValue("AUTOMATION", "data", "userId");
        payload.SetValue(now, "data", "requestDateTime");
        payload.SetValue(patient.PatientId, "data", "patient", "identification", "clientPatientIds", 0, "patientId");
        payload.SetValue(patient.FirstName, "data", "patient", "name", "firstName");
        payload.SetValue(patient.LastName, "data", "patient", "name", "lastName");
        payload.SetValue(patient.DateOfBirth, "data", "patient", "dateOfBirth");
        payload.SetValue(patient.Gender, "data", "patient", "genderAndSex", "administrativeGender");
        ResizeMedications((JsonArray)payload.Required("data", "medications", "medicationTransferred"), medicationCount);
    }

    private static void ResizeMedications(JsonArray medications, int count)
    {
        if (medications.Count == 0) throw new InvalidOperationException("The payload template has no medication records.");
        var originals = medications.Select(item => item!.DeepClone()).ToList();
        medications.Clear();
        for (var index = 0; index < count; index++)
        {
            medications.Add(originals[index % originals.Count].DeepClone());
        }
    }

    public static string Serialize(JsonNode payload) => payload.ToJsonString(new JsonSerializerOptions { WriteIndented = true });
}
