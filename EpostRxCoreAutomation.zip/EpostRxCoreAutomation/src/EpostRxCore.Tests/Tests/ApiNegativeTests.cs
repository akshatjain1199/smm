using System.Net;
using EpostRxCore.Tests.Base;
using EpostRxCore.Tests.Data;
using NUnit.Framework;

namespace EpostRxCore.Tests.Tests;

[TestFixture]
[Category("Functional")]
[Category("Negative")]
[Explicit("Calls the QA APIs with deliberately invalid request data.")]
public sealed class ApiNegativeTests : FunctionalTestBase
{
    [TestCase("CPD")]
    [TestCase("AssistRx")]
    public async Task TC_RXCORE_NEG_001_InvalidBearerToken_Returns401(string clientKey)
    {
        var client = Clients.Get(clientKey);
        var payload = Payloads.BuildProducer(client, PatientDataFactory.CreateNew(), 1);
        var result = await Sender.PostAsync(Settings.Api.ProducerUrl, payload, "invalid-token", client);
        Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.Unauthorized));
    }

    [Test]
    public async Task TC_RXCORE_NEG_002_InvalidIntakeId_DoesNotReturn202()
    {
        var client = Clients.Get("CPD");
        var patient = PatientDataFactory.CreateNew();
        var token = await Tokens.GetTokenAsync();
        var payload = Payloads.BuildRxCore(client, patient, 1, "INVALID-INTAKE-ID", string.Empty);
        var result = await Sender.PostAsync(Settings.Api.RxCoreUrl, payload, token, client);
        Assert.That(result.StatusCode, Is.Not.EqualTo(HttpStatusCode.Accepted));
    }
}
