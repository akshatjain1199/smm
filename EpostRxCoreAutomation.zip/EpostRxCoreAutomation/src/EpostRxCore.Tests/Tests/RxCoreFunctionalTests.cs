using EpostRxCore.Tests.Base;
using EpostRxCore.Tests.Data;
using EpostRxCore.Tests.Models;
using NUnit.Framework;

namespace EpostRxCore.Tests.Tests;

[TestFixture]
[Category("Functional")]
[Category("RxCore")]
[Explicit("Calls QA APIs and validates the created order in ePost.")]
public sealed class RxCoreFunctionalTests : FunctionalTestBase
{
    [TestCase("CPD", TestName = "TC_RXCORE_001_NewPatient_OneRx_CPD")]
    [TestCase("AssistRx", TestName = "TC_RXCORE_001_NewPatient_OneRx_AssistRx")]
    [TestCase("Andel", TestName = "TC_RXCORE_001_NewPatient_OneRx_Andel")]
    [TestCase("Apaly", TestName = "TC_RXCORE_001_NewPatient_OneRx_Apaly")]
    public async Task TC_RXCORE_001_NewPatient_OneRx_AllClients(string clientKey)
    {
        await Run(clientKey, PatientDataFactory.CreateNew(), 1);
    }

    [TestCase("CPD", TestName = "TC_RXCORE_002_NewPatient_MultipleRx_CPD")]
    [TestCase("AssistRx", TestName = "TC_RXCORE_002_NewPatient_MultipleRx_AssistRx")]
    [TestCase("Andel", TestName = "TC_RXCORE_002_NewPatient_MultipleRx_Andel")]
    [TestCase("Apaly", TestName = "TC_RXCORE_002_NewPatient_MultipleRx_Apaly")]
    public async Task TC_RXCORE_002_NewPatient_MultipleRx_AllClients(string clientKey)
    {
        await Run(clientKey, PatientDataFactory.CreateNew(), 2);
    }

    [TestCase("CPD", TestName = "TC_RXCORE_003_ExistingPatient_CPD")]
    [TestCase("AssistRx", TestName = "TC_RXCORE_003_ExistingPatient_AssistRx")]
    [TestCase("Andel", TestName = "TC_RXCORE_003_ExistingPatient_Andel")]
    [TestCase("Apaly", TestName = "TC_RXCORE_003_ExistingPatient_Apaly")]
    public async Task TC_RXCORE_003_ExistingPatient_CreatesAnotherOrder(string clientKey)
    {
        var patient = PatientDataFactory.CreateNew();
        var first = await Run(clientKey, patient, 1);
        var second = await Run(clientKey, patient, 1);
        Assert.Multiple(() =>
        {
            Assert.That(second.Patient, Is.EqualTo(first.Patient));
            Assert.That(second.Producer.IntakeId, Is.Not.EqualTo(first.Producer.IntakeId));
            Assert.That(second.RxCore.OrderNumber, Is.Not.EqualTo(first.RxCore.OrderNumber));
        });
    }

    private Task<WorkflowResult> Run(string clientKey, PatientData patient, int medicationCount) =>
        Workflow.ExecuteAsync(Clients.Get(clientKey), patient, medicationCount, Report, validateInEpost: true);
}
