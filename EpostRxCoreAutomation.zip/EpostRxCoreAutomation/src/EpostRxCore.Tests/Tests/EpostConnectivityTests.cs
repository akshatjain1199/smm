using EpostRxCore.Tests.Configuration;
using EpostRxCore.Tests.Drivers;
using EpostRxCore.Tests.Pages;
using NUnit.Framework;

namespace EpostRxCore.Tests.Tests;

[TestFixture]
[Category("Connectivity")]
[Explicit("Opens the configured ePost environment in Edge IE mode.")]
public sealed class EpostConnectivityTests
{
    [Test]
    public void TC_CONNECT_001_EpostLoginPageLoads()
    {
        var settings = SettingsLoader.Load();
        using var driver = BrowserFactory.Create(settings.Epost);
        var page = new EpostLoginPage(driver, settings.Epost);
        page.Open(settings.Epost.ResolveUrl());
        Assert.That(driver.Title, Is.Not.Empty);
    }
}
