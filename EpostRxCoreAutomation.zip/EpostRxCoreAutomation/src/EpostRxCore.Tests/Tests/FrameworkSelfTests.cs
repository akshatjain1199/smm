using EpostRxCore.Tests.Configuration;
using EpostRxCore.Tests.Data;
using EpostRxCore.Tests.Utilities;
using NUnit.Framework;

namespace EpostRxCore.Tests.Tests;

[TestFixture]
[Category("SelfTest")]
public sealed class FrameworkSelfTests
{
    [Test]
    public void TC_SELF_001_AllClientProfilesAreConfigured()
    {
        var repository = new ClientProfileRepository();
        Assert.That(repository.All.Select(client => client.Key), Is.EquivalentTo(new[] { "CPD", "AssistRx", "Andel", "Apaly" }));
        Assert.That(repository.Get("AssistRx").ExpectedDispenseLocation, Is.EqualTo("Coassist"));
    }

    [Test]
    public void TC_SELF_002_NewPatientDataFollowsRules()
    {
        var patient = PatientDataFactory.CreateNew();
        Assert.Multiple(() =>
        {
            Assert.That(patient.PatientId, Does.Match("^[0-9]{8}$"));
            Assert.That(patient.FirstName, Does.Match("^[A-Za-z]+$"));
            Assert.That(patient.LastName, Does.Match("^[A-Za-z]+$"));
            Assert.That(DateTime.Parse(patient.DateOfBirth).Year, Is.InRange(1950, 2000));
            Assert.That(patient.Gender, Is.AnyOf("M", "F"));
        });
    }

    [Test]
    public void TC_SELF_003_PayloadsUseSamePatientAndProducerIntakeId()
    {
        var settings = SettingsLoader.Load();
        var client = new ClientProfileRepository().Get("CPD");
        var patient = PatientDataFactory.CreateNew();
        var service = new PayloadTemplateService(settings.Api);
        var producer = service.BuildProducer(client, patient, 2);
        var rxCore = service.BuildRxCore(client, patient, 2, "INTAKE-123", "LIFE-456");

        Assert.Multiple(() =>
        {
            Assert.That(rxCore["id"]!.GetValue<string>(), Is.EqualTo("INTAKE-123"));
            Assert.That(producer.Required("data", "patient", "identification", "clientPatientIds", 0, "patientId").GetValue<string>(), Is.EqualTo(patient.PatientId));
            Assert.That(rxCore.Required("data", "patient", "identification", "clientPatientIds", 0, "patientId").GetValue<string>(), Is.EqualTo(patient.PatientId));
            Assert.That(producer.Required("data", "medications", "medicationTransferred").AsArray(), Has.Count.EqualTo(2));
            Assert.That(rxCore.Required("data", "medications", "medicationTransferred").AsArray(), Has.Count.EqualTo(2));
            Assert.That(rxCore["lifeCycleId"]!.GetValue<string>(), Is.EqualTo("PRESERVED_TEMPLATE_VALUE"));
        });
    }
}
