namespace EpostRxCore.Tests.Configuration;

public sealed class AutomationSettings
{
    public string EnvironmentName { get; set; } = "QA";
    public ApiSettings Api { get; set; } = new();
    public EpostSettings Epost { get; set; } = new();
    public ReportSettings Report { get; set; } = new();
}

public sealed class ApiSettings
{
    public string TokenUrl { get; set; } = string.Empty;
    public string ClientIdEnvironmentVariable { get; set; } = "EPOST_API_CLIENT_ID";
    public string ClientSecretEnvironmentVariable { get; set; } = "EPOST_API_CLIENT_SECRET";
    public string ScopeEnvironmentVariable { get; set; } = "EPOST_API_SCOPE";
    public string BearerTokenEnvironmentVariable { get; set; } = "EPOST_API_BEARER_TOKEN";
    public string PisApiKeyEnvironmentVariable { get; set; } = "EPOST_PIS_API_KEY";
    public string PisApiKeyHeaderName { get; set; } = "xApikey_PIS";
    public string UserIdHeaderName { get; set; } = "x-user-id";
    public string SourceSystemHeaderName { get; set; } = "x-src-sys";
    public string TraceIdHeaderName { get; set; } = "x-trace-id";
    public string ProducerUrl { get; set; } = string.Empty;
    public string RxCoreUrl { get; set; } = string.Empty;
    public string UserId { get; set; } = "AUTOMATION";
    public int RequestTimeoutSeconds { get; set; } = 90;
    public int DelayBetweenProducerAndRxCoreSeconds { get; set; } = 12;
    public bool MapLifecycleIdToRxCore { get; set; }
}

public sealed class EpostSettings
{
    public string Environment { get; set; } = "QA3";
    public string Qa1Url { get; set; } = string.Empty;
    public string Qa2Url { get; set; } = string.Empty;
    public string Qa3Url { get; set; } = string.Empty;
    public bool UseIeMode { get; set; } = true;
    public string EdgeBinaryPath { get; set; } = string.Empty;
    public string IeDriverDirectoryEnvironmentVariable { get; set; } = "EPOST_IE_DRIVER_DIRECTORY";
    public string UsernameEnvironmentVariable { get; set; } = "EPOST_USERNAME";
    public string PasswordEnvironmentVariable { get; set; } = "EPOST_PASSWORD";
    public string SitePinEnvironmentVariable { get; set; } = "EPOST_SITE_PIN";
    public int DefaultWaitSeconds { get; set; } = 30;
    public int OrderPollIntervalSeconds { get; set; } = 10;
    public int OrderPollTimeoutSeconds { get; set; } = 180;

    public string ResolveUrl() => Environment.Trim().ToUpperInvariant() switch
    {
        "QA1" => Qa1Url,
        "QA2" => Qa2Url,
        "QA3" => Qa3Url,
        _ => throw new InvalidOperationException($"Unsupported ePost environment '{Environment}'. Use QA1, QA2 or QA3.")
    };
}

public sealed class ReportSettings
{
    public string RootDirectory { get; set; } = "TestResults";
    public bool CapturePassedValidationScreenshots { get; set; } = true;
    public bool CaptureFailureScreenshots { get; set; } = true;
}
