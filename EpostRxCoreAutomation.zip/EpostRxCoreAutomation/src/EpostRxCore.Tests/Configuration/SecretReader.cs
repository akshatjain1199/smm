namespace EpostRxCore.Tests.Configuration;

public static class SecretReader
{
    public static string Required(string environmentVariableName)
    {
        var value = Environment.GetEnvironmentVariable(environmentVariableName);
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new InvalidOperationException(
                $"Required protected variable '{environmentVariableName}' is not set. " +
                "Set it locally or as a secret pipeline variable; never place the value in appsettings.json.");
        }

        return value;
    }

    public static string? Optional(string environmentVariableName) =>
        Environment.GetEnvironmentVariable(environmentVariableName);
}
