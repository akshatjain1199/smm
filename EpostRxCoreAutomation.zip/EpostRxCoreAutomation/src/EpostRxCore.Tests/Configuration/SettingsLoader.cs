using System.Text.Json;

namespace EpostRxCore.Tests.Configuration;

public static class SettingsLoader
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public static AutomationSettings Load()
    {
        var configuredPath = Environment.GetEnvironmentVariable("AUTOMATION_SETTINGS_FILE");
        var path = string.IsNullOrWhiteSpace(configuredPath)
            ? Path.Combine(AppContext.BaseDirectory, "TestData", "appsettings.json")
            : configuredPath;

        if (!File.Exists(path))
        {
            throw new FileNotFoundException("Automation settings file was not found.", path);
        }

        var settings = JsonSerializer.Deserialize<AutomationSettings>(File.ReadAllText(path), JsonOptions)
            ?? throw new InvalidOperationException("Automation settings could not be read.");

        ApplyEnvironmentOverrides(settings);
        return settings;
    }

    private static void ApplyEnvironmentOverrides(AutomationSettings settings)
    {
        settings.EnvironmentName = ReadOptional("AUTOMATION_ENVIRONMENT", settings.EnvironmentName);
        settings.Epost.Environment = ReadOptional("EPOST_ENVIRONMENT", settings.Epost.Environment);
        settings.Api.ProducerUrl = ReadOptional("EPOST_PRODUCER_URL", settings.Api.ProducerUrl);
        settings.Api.RxCoreUrl = ReadOptional("EPOST_RXCORE_URL", settings.Api.RxCoreUrl);
        settings.Epost.UseIeMode = ReadOptionalBoolean("EPOST_USE_IE_MODE", settings.Epost.UseIeMode);
    }

    private static string ReadOptional(string variableName, string fallback) =>
        Environment.GetEnvironmentVariable(variableName) is { Length: > 0 } value ? value : fallback;

    private static bool ReadOptionalBoolean(string variableName, bool fallback) =>
        bool.TryParse(Environment.GetEnvironmentVariable(variableName), out var value) ? value : fallback;
}
