using EpostRxCore.Tests.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.IE;

namespace EpostRxCore.Tests.Drivers;

public static class BrowserFactory
{
    public static IWebDriver Create(EpostSettings settings)
    {
        IWebDriver driver = settings.UseIeMode ? CreateIeMode(settings) : CreateRegularEdge();
        driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(90);
        driver.Manage().Timeouts().ImplicitWait = TimeSpan.Zero;
        try { driver.Manage().Window.Maximize(); } catch (WebDriverException) { }
        return driver;
    }

    private static IWebDriver CreateRegularEdge()
    {
        var options = new EdgeOptions();
        options.AddArgument("--start-maximized");
        options.AddArgument("--no-first-run");
        return new EdgeDriver(options);
    }

    private static IWebDriver CreateIeMode(EpostSettings settings)
    {
        var driverDirectory = SecretReader.Optional(settings.IeDriverDirectoryEnvironmentVariable);
        InternetExplorerDriverService service = string.IsNullOrWhiteSpace(driverDirectory)
            ? InternetExplorerDriverService.CreateDefaultService()
            : InternetExplorerDriverService.CreateDefaultService(driverDirectory);
        service.HideCommandPromptWindow = true;

        var options = new InternetExplorerOptions
        {
            AttachToEdgeChrome = true,
            EdgeExecutablePath = settings.EdgeBinaryPath,
            IgnoreZoomLevel = true,
            IntroduceInstabilityByIgnoringProtectedModeSettings = true,
            RequireWindowFocus = false
        };
        return new InternetExplorerDriver(service, options, TimeSpan.FromSeconds(120));
    }
}
