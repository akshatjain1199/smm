using OpenQA.Selenium;

namespace EpostRxCore.Tests.Drivers;

public sealed class LegacyElementFinder
{
    private readonly IWebDriver _driver;

    public LegacyElementFinder(IWebDriver driver) => _driver = driver;

    public IWebElement Find(By by, TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow + timeout;
        Exception? lastError = null;
        while (DateTime.UtcNow < deadline)
        {
            try
            {
                _driver.SwitchTo().DefaultContent();
                var element = FindRecursive(by, 0);
                if (element is not null && element.Displayed) return element;
            }
            catch (Exception error) when (error is NoSuchElementException or StaleElementReferenceException or WebDriverException)
            {
                lastError = error;
            }
            Thread.Sleep(500);
        }

        _driver.SwitchTo().DefaultContent();
        throw new NoSuchElementException($"Element '{by}' was not found in the page or its frames.", lastError);
    }

    public IReadOnlyList<IWebElement> FindAll(By by)
    {
        _driver.SwitchTo().DefaultContent();
        var results = new List<IWebElement>();
        CollectRecursive(by, 0, results);
        _driver.SwitchTo().DefaultContent();
        return results;
    }

    public string ReadBodyTextAcrossFrames()
    {
        _driver.SwitchTo().DefaultContent();
        var text = new List<string>();
        CollectBodyText(0, text);
        _driver.SwitchTo().DefaultContent();
        return string.Join(Environment.NewLine, text.Where(value => !string.IsNullOrWhiteSpace(value)));
    }

    private IWebElement? FindRecursive(By by, int depth)
    {
        var direct = _driver.FindElements(by).FirstOrDefault(element => element.Displayed);
        if (direct is not null) return direct;
        if (depth >= 8) return null;

        var frames = _driver.FindElements(By.CssSelector("frame,iframe"));
        for (var index = 0; index < frames.Count; index++)
        {
            try
            {
                _driver.SwitchTo().Frame(frames[index]);
                var found = FindRecursive(by, depth + 1);
                if (found is not null) return found;
                _driver.SwitchTo().ParentFrame();
            }
            catch (WebDriverException)
            {
                _driver.SwitchTo().DefaultContent();
            }
        }
        return null;
    }

    private void CollectRecursive(By by, int depth, ICollection<IWebElement> results)
    {
        foreach (var element in _driver.FindElements(by)) results.Add(element);
        if (depth >= 8) return;
        var frames = _driver.FindElements(By.CssSelector("frame,iframe"));
        for (var index = 0; index < frames.Count; index++)
        {
            try
            {
                _driver.SwitchTo().Frame(frames[index]);
                CollectRecursive(by, depth + 1, results);
                _driver.SwitchTo().ParentFrame();
            }
            catch (WebDriverException)
            {
                _driver.SwitchTo().DefaultContent();
            }
        }
    }

    private void CollectBodyText(int depth, ICollection<string> values)
    {
        var body = _driver.FindElements(By.TagName("body")).FirstOrDefault();
        if (body is not null) values.Add(body.Text);
        if (depth >= 8) return;
        var frames = _driver.FindElements(By.CssSelector("frame,iframe"));
        for (var index = 0; index < frames.Count; index++)
        {
            try
            {
                _driver.SwitchTo().Frame(frames[index]);
                CollectBodyText(depth + 1, values);
                _driver.SwitchTo().ParentFrame();
            }
            catch (WebDriverException)
            {
                _driver.SwitchTo().DefaultContent();
            }
        }
    }
}
