using EpostRxCore.Tests.Api;
using EpostRxCore.Tests.Configuration;
using EpostRxCore.Tests.Data;
using EpostRxCore.Tests.Reporting;
using EpostRxCore.Tests.Workflow;
using NUnit.Framework;

namespace EpostRxCore.Tests.Base;

public abstract class FunctionalTestBase
{
    private HttpClient? _httpClient;
    protected AutomationSettings Settings { get; private set; } = null!;
    protected ClientProfileRepository Clients { get; private set; } = null!;
    protected PayloadTemplateService Payloads { get; private set; } = null!;
    protected OAuthTokenClient Tokens { get; private set; } = null!;
    protected ApiRequestSender Sender { get; private set; } = null!;
    protected RxCoreApiClient Api { get; private set; } = null!;
    protected RxCoreWorkflowService Workflow { get; private set; } = null!;
    protected HtmlExecutionReport Report { get; private set; } = null!;

    [SetUp]
    public void FrameworkSetUp()
    {
        Settings = SettingsLoader.Load();
        Clients = new ClientProfileRepository();
        Payloads = new PayloadTemplateService(Settings.Api);
        _httpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(Settings.Api.RequestTimeoutSeconds) };
        Tokens = new OAuthTokenClient(_httpClient, Settings.Api);
        Sender = new ApiRequestSender(_httpClient, Settings.Api);
        Api = new RxCoreApiClient(Sender, Settings.Api);
        Workflow = new RxCoreWorkflowService(Settings, Payloads, Tokens, Api);
        var testName = TestContext.CurrentContext.Test.Name;
        Report = new HtmlExecutionReport(Settings.Report.RootDirectory, testName, $"{Settings.EnvironmentName}/{Settings.Epost.Environment}");
    }

    [TearDown]
    public void FrameworkTearDown()
    {
        var outcome = TestContext.CurrentContext.Result.Outcome.Status.ToString();
        Report.AddInformation("NUnit result", outcome);
        Report.Write();
        TestContext.Out.WriteLine($"HTML report: {Report.ReportPath}");
        _httpClient?.Dispose();
    }
}
