using EpostRxCore.Tests.Configuration;
using EpostRxCore.Tests.Drivers;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace EpostRxCore.Tests.Pages;

public sealed class EpostOrderSearchPage
{
    private readonly IWebDriver _driver;
    private readonly LegacyElementFinder _finder;
    private readonly TimeSpan _wait;

    public EpostOrderSearchPage(IWebDriver driver, EpostSettings settings)
    {
        _driver = driver;
        _finder = new LegacyElementFinder(driver);
        _wait = TimeSpan.FromSeconds(settings.DefaultWaitSeconds);
    }

    public bool TryOpenOrder(string orderNumber)
    {
        try
        {
            _finder.Find(By.CssSelector("a[href*='gotoOrderSearch']"), _wait).Click();
            SwitchToNewestWindow();
            var criteria = _finder.Find(By.Name("criteriaId"), _wait);
            new SelectElement(criteria).SelectByValue("1");
            var keyword = _finder.Find(By.Name("keywordsearch"), _wait);
            keyword.Clear();
            keyword.SendKeys(orderNumber);
            keyword.SendKeys(Keys.Enter);

            var result = _finder.Find(
                By.XPath($"//a[contains(@href,'processOrderLockCheck') and contains(normalize-space(.),'{orderNumber}') ]"),
                TimeSpan.FromSeconds(10));
            result.Click();
            SwitchToNewestWindow();
            return true;
        }
        catch (NoSuchElementException)
        {
            _driver.SwitchTo().DefaultContent();
            return false;
        }
    }

    private void SwitchToNewestWindow()
    {
        var handles = _driver.WindowHandles;
        if (handles.Count > 0) _driver.SwitchTo().Window(handles[^1]);
    }
}
