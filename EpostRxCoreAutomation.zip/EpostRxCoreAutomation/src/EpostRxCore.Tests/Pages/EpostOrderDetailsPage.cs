using System.Text.RegularExpressions;
using EpostRxCore.Tests.Drivers;
using EpostRxCore.Tests.Models;
using OpenQA.Selenium;

namespace EpostRxCore.Tests.Pages;

public sealed class EpostOrderDetailsPage
{
    private readonly IWebDriver _driver;
    private readonly LegacyElementFinder _finder;

    public EpostOrderDetailsPage(IWebDriver driver)
    {
        _driver = driver;
        _finder = new LegacyElementFinder(driver);
    }

    public EpostOrderSnapshot Read(string expectedOrderNumber)
    {
        var text = ReadAllVisibleText();
        var orderNumber = Match(text, @"Order Invoice Number\s*:?\s*(\d+)") ?? expectedOrderNumber;
        var status = Match(text, @"Order Status\s*:?\s*([^\r\n]+)") ?? string.Empty;
        var dispense = Match(text, @"Dispense Location\s*:?\s*([^\r\n]+)") ?? string.Empty;
        var origination = Match(text, @"Origination\s*:?\s*([^\r\n]+)") ?? string.Empty;
        var patient = Match(text, @"Patient\s*:?\s*([^\r\n]+)") ?? string.Empty;
        var rxMatches = Regex.Matches(text, @"Rx/Fill\s*:?\s*([^\r\n]+)", RegexOptions.IgnoreCase);
        var prescriptions = rxMatches
            .Select(match => new EpostRxSnapshot(match.Groups[1].Value.Trim(), string.Empty, string.Empty))
            .ToList();

        return new EpostOrderSnapshot(orderNumber.Trim(), status.Trim(), dispense.Trim(), origination.Trim(), patient.Trim(), prescriptions);
    }

    public string ReadAllVisibleText()
        => _finder.ReadBodyTextAcrossFrames();

    private static string? Match(string input, string pattern)
    {
        var match = Regex.Match(input, pattern, RegexOptions.IgnoreCase);
        return match.Success ? match.Groups[1].Value : null;
    }
}
