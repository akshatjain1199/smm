using EpostRxCore.Tests.Configuration;
using EpostRxCore.Tests.Drivers;
using OpenQA.Selenium;

namespace EpostRxCore.Tests.Pages;

public sealed class EpostLoginPage
{
    private readonly IWebDriver _driver;
    private readonly LegacyElementFinder _finder;
    private readonly TimeSpan _wait;

    public EpostLoginPage(IWebDriver driver, EpostSettings settings)
    {
        _driver = driver;
        _finder = new LegacyElementFinder(driver);
        _wait = TimeSpan.FromSeconds(settings.DefaultWaitSeconds);
    }

    public void Open(string url) => _driver.Navigate().GoToUrl(url);

    public void Login(string username, string password, string sitePin)
    {
        // A manually preserved enterprise session may already be authenticated.
        if (!_driver.FindElements(By.Name("user_name")).Any())
        {
            try { _finder.Find(By.Name("user_name"), TimeSpan.FromSeconds(5)); }
            catch (NoSuchElementException) { return; }
        }

        Type(_finder.Find(By.Name("user_name"), _wait), username);
        Type(_finder.Find(By.Name("user_password"), _wait), password);
        Type(_finder.Find(By.Name("pin"), _wait), sitePin);
        _finder.Find(By.Name("B5"), _wait).Click();
        WaitUntilLoggedIn();
    }

    public bool IsLoginPageVisible()
    {
        try { _finder.Find(By.Name("user_name"), TimeSpan.FromSeconds(3)); return true; }
        catch (NoSuchElementException) { return false; }
    }

    private void WaitUntilLoggedIn()
    {
        var deadline = DateTime.UtcNow + _wait;
        while (DateTime.UtcNow < deadline)
        {
            if (!IsLoginPageVisible()) return;
            Thread.Sleep(500);
        }
        throw new TimeoutException("ePost login did not complete within the configured wait time.");
    }

    private static void Type(IWebElement element, string value)
    {
        element.Clear();
        element.SendKeys(value);
    }
}
